package com.lupoxan.practica1evaluacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class PlayActivity extends AppCompatActivity {

    ImageView galleta;
    TextView crono, puntos;
    int cont = 10;
    Boolean flag = false;
    int clicks = 0;
    String nivel,player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        galleta = findViewById(R.id.galletaClick);
        crono = findViewById(R.id.crono);
        puntos = findViewById(R.id.textView3);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(PlayActivity.this);
        nivel = sp.getString("levels","");
        player = sp.getString("player","");

        setTitle(player);
        
        switch (nivel){
            case "Fácil":
                cont = 20;
                break;
            case "Normal":
                cont = 10;
                break;
            case "Dificil":
                cont = 5;
                break;
        }

        crono.setText(String.format("00:%02d:00", cont));
        puntos.setText(clicks + " clicks");

        galleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = true;
                clicks++;
                puntos.setText(clicks + " clicks");
            }
        });

        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                if (flag) {
                    if (cont > 0) {
                        cont--;
                        crono.setText(String.format("00:%02d:00", cont));
                    } else {
                        flag = false;
                        galleta.setEnabled(false);
                    }
                }
            }
        };
        timer.scheduleAtFixedRate(timerTask, 1, 1000);
    }

    public void alerta(String title, String body){
        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(PlayActivity.this);
        alertBuilder.setTitle(title);
        alertBuilder.setMessage(body);
        alertBuilder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                galleta.setEnabled(true);

                switch (nivel){
                    case "Fácil":
                        cont = 20;
                        break;
                    case "Normal":
                        cont = 10;
                        break;
                    case "Dificil":
                        cont = 5;
                        break;
                }

                clicks = 0;
                crono.setText(String.format("00:%02d:00", cont));
                puntos.setText(clicks + " clicks");
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alertBuilder.create();
        alertBuilder.show();
    }

    @Override
    public void onBackPressed() {
        flag = false;
        alerta("Volver","¿Volver a jugar?");
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            flag = false;
            alerta("Volver","¿Volver a jugar?");
            return true;
        }else{
            return super.onOptionsItemSelected(item);
        }

    }
}
