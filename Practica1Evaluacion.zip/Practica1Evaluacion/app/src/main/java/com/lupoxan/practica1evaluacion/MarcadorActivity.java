package com.lupoxan.practica1evaluacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MarcadorActivity extends AppCompatActivity {

    ArrayAdapter<String> adapter;
    ArrayList<String> datos = new ArrayList<>();
    ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marcador);

        lista = findViewById(R.id.records);

        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,datos);

        lista.setAdapter(adapter);

    }
}
